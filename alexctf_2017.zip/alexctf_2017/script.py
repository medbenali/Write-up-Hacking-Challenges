#!/usr/bin/env python

from steganography.steganography import Steganography
print Steganography.decode("cat_with_secrets.png")
